# JuniorPack
This is a Minecraft Optifine/Vanilla resourcepack

Credits for some parts of the resourcepack

	-Vannillatweaks (https://vanillatweaks.net/picker/resource-packs/)
		Vannillatweaks is an awsome website with awsome people where you can put
		different little but awsome resourcepacks they did together
	
	-Scythe29       (https://www.planetminecraft.com/member/scythe29/)
		Scythe is a good friend of mine who really helped me out sometimes and
		even if there are no textures from him in this resourcepack i still wanna
		tell you that you should check him out!
    
    
